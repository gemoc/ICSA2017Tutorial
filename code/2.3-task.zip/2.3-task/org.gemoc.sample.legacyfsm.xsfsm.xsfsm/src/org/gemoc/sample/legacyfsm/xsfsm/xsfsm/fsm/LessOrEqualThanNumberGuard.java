/**
 */
package org.gemoc.sample.legacyfsm.xsfsm.xsfsm.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Less Or Equal Than Number Guard</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sample.legacyfsm.xsfsm.xsfsm.fsm.FsmPackage#getLessOrEqualThanNumberGuard()
 * @model
 * @generated
 */
public interface LessOrEqualThanNumberGuard extends NumberGuard {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	boolean holds();

} // LessOrEqualThanNumberGuard
