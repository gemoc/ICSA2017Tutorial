package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.adapters.xmontiarcwithautomatonmt.runtime;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.adapters.xmontiarcwithautomatonmt.XMontiArcWithAutomatonMTAdaptersFactory;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomatonmt.runtime.Message;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomatonmt.runtime.RuntimeFactory;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomatonmt.runtime.RuntimePackage;

@SuppressWarnings("all")
public class RuntimeFactoryAdapter extends EFactoryImpl implements RuntimeFactory {
  private XMontiArcWithAutomatonMTAdaptersFactory adaptersFactory = ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.adapters.xmontiarcwithautomatonmt.XMontiArcWithAutomatonMTAdaptersFactory.getInstance();
  
  private ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.runtime.RuntimeFactory runtimeAdaptee = ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.runtime.RuntimeFactory.eINSTANCE;
  
  @Override
  public Message createMessage() {
    return adaptersFactory.createMessageAdapter(runtimeAdaptee.createMessage(), null);
  }
  
  @Override
  public EPackage getEPackage() {
    return getRuntimePackage();
  }
  
  public RuntimePackage getRuntimePackage() {
    return ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomatonmt.runtime.RuntimePackage.eINSTANCE;
  }
}
