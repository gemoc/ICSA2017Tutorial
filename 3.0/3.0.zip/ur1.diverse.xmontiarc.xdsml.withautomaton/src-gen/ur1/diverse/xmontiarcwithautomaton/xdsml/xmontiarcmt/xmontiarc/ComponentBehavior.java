/**
 */
package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcmt.xmontiarc;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcmt.xmontiarc.XmontiarcPackage#getComponentBehavior()
 * @model abstract="true"
 * @generated
 */
public interface ComponentBehavior extends EObject {
} // ComponentBehavior
