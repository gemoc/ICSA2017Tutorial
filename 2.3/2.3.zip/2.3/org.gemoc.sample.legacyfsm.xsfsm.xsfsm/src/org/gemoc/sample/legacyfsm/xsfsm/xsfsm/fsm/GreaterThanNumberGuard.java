/**
 */
package org.gemoc.sample.legacyfsm.xsfsm.xsfsm.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater Than Number Guard</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sample.legacyfsm.xsfsm.xsfsm.fsm.FsmPackage#getGreaterThanNumberGuard()
 * @model
 * @generated
 */
public interface GreaterThanNumberGuard extends NumberGuard {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	boolean holds();

} // GreaterThanNumberGuard
