package org.gemoc.sample.legacyfsm.fsm.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Abstract;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Step;
import org.gemoc.sample.legacyfsm.fsm.Guard;
import org.gemoc.sample.legacyfsm.fsm.k3dsa.GuardAspectGuardAspectProperties;

@Aspect(className = Guard.class)
@SuppressWarnings("all")
public abstract class GuardAspect {
  @Step
  @Abstract
  public static boolean holds(final Guard _self) {
    final org.gemoc.sample.legacyfsm.fsm.k3dsa.GuardAspectGuardAspectProperties _self_ = org.gemoc.sample.legacyfsm.fsm.k3dsa.GuardAspectGuardAspectContext.getSelf(_self);
    Object result = null;
     if (_self instanceof org.gemoc.sample.legacyfsm.fsm.EqualNumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.EqualNumberGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.EqualNumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.LessThanNumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.LessThanNumberGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.LessThanNumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.StringGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.StringGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.StringGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.GreaterThanNumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.GreaterThanNumberGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.GreaterThanNumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.LessOrEqualThanNumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.LessOrEqualThanNumberGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.LessOrEqualThanNumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.GreaterOrEqualThanNumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.GreaterOrEqualThanNumberGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.GreaterOrEqualThanNumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.NumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.NumberGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.NumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.BooleanGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.BooleanGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.BooleanGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.Guard){
    					fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    						@Override
    						public void execute() {
    							addToResult(org.gemoc.sample.legacyfsm.fsm.k3dsa.GuardAspect._privk3_holds(_self_, (org.gemoc.sample.legacyfsm.fsm.Guard)_self));
    						}
    					};
    					fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    					if (stepManager != null) {
    						stepManager.executeStep(_self,command,"Guard","holds");
    					} else {
    						fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IEventManager eventManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.EventManagerRegistry.getInstance().findEventManager(_self);
    						if (eventManager != null) {
    							eventManager.manageEvents();
    						}
    						command.execute();
    					}
    					result = command.getResult();
    					;
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
    return (boolean)result;
  }
  
  protected static boolean _privk3_holds(final GuardAspectGuardAspectProperties _self_, final Guard _self) {
    throw new java.lang.RuntimeException("Not implemented");
  }
}
