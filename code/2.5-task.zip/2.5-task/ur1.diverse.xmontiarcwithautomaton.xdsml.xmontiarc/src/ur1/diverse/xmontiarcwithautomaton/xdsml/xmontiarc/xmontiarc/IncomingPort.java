/**
 */
package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.xmontiarc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Incoming Port</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.xmontiarc.XmontiarcPackage#getIncomingPort()
 * @model
 * @generated
 */
public interface IncomingPort extends Port {
} // IncomingPort
