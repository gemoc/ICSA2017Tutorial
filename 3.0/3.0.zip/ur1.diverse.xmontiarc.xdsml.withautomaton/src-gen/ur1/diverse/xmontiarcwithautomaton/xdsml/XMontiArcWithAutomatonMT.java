package ur1.diverse.xmontiarcwithautomaton.xdsml;

import fr.inria.diverse.melange.lib.IModelType;
import java.io.IOException;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomatonmt.runtime.RuntimeFactory;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomatonmt.xmontiarc.XmontiarcFactory;

@SuppressWarnings("all")
public interface XMontiArcWithAutomatonMT extends IModelType {
  public abstract EList<EObject> getContents();
  
  public abstract XmontiarcFactory getXmontiarcFactory();
  
  public abstract RuntimeFactory getRuntimeFactory();
  
  public abstract void save(final String uri) throws IOException;
}
