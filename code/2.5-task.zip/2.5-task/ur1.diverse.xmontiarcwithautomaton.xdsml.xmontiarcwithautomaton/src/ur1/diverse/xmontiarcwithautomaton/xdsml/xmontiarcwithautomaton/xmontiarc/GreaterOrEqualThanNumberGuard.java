/**
 */
package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater Or Equal Than Number Guard</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.XmontiarcPackage#getGreaterOrEqualThanNumberGuard()
 * @model
 * @generated
 */
public interface GreaterOrEqualThanNumberGuard extends NumberGuard {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	boolean holds();

} // GreaterOrEqualThanNumberGuard
