package org.gemoc.sample.legacyfsm.xsfsm.xsfsm.aspects;

@SuppressWarnings("all")
public class TransitionAspectTransitionAspectProperties {
}
