package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.Variable;

/**
 * class NonDeterminism extends Exception {
 * }
 */
@Aspect(className = Variable.class)
@SuppressWarnings("all")
public class VariableAspect {
}
