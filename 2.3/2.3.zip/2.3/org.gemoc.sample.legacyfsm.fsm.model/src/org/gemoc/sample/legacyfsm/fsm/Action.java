/**
 */
package org.gemoc.sample.legacyfsm.fsm;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sample.legacyfsm.fsm.FsmPackage#getAction()
 * @model abstract="true"
 * @generated
 */
public interface Action extends EObject {
} // Action
