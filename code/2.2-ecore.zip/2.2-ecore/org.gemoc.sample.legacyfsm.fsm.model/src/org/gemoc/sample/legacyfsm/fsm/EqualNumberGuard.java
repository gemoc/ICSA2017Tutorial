/**
 */
package org.gemoc.sample.legacyfsm.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equal Number Guard</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sample.legacyfsm.fsm.FsmPackage#getEqualNumberGuard()
 * @model
 * @generated
 */
public interface EqualNumberGuard extends NumberGuard {
} // EqualNumberGuard
