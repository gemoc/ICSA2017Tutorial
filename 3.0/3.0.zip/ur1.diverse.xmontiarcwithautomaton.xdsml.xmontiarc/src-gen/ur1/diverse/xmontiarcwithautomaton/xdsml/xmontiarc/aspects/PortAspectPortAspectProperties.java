package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.aspects;

import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public class PortAspectPortAspectProperties {
  public EObject value;
}
