package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Step;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.InputOutput;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.aspects.PortAspect;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.aspects.SubcomponentAspectSubcomponentAspectProperties;
import ur1.diverse.xmontiarc.runtime.GroovyInterpreter;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.ComponentBehavior;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.ComponentType;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.GroovyComponentBehavior;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.OutgoingPort;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.Port;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.Subcomponent;

@Aspect(className = Subcomponent.class)
@SuppressWarnings("all")
public class SubcomponentAspect {
  @Step
  public static void compute(final Subcomponent _self) {
	final ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.aspects.SubcomponentAspectSubcomponentAspectProperties _self_ = ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.aspects.SubcomponentAspectSubcomponentAspectContext
			.getSelf(_self);
	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
		@Override
		public void execute() {
			_privk3_compute(_self_, _self);
		}
	};
	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager manager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry
			.getInstance().findStepManager(_self);
	if (manager != null) {
		manager.executeStep(_self, command, "Subcomponent", "compute");
	} else {
		fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IEventManager eventManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.EventManagerRegistry
				.getInstance().findEventManager(null);
		if (eventManager != null) {
			eventManager.manageEvents();
		}
		command.execute();
	}
	;
	;
}
  
  protected static void _privk3_compute(final SubcomponentAspectSubcomponentAspectProperties _self_, final Subcomponent _self) {
    ComponentType _type = _self.getType();
    String _name = _type.getName();
    String _plus = ("### Computing behavior for subcomponent \'" + _name);
    String _plus_1 = (_plus + ".");
    String _name_1 = _self.getName();
    String _plus_2 = (_plus_1 + _name_1);
    String _plus_3 = (_plus_2 + "\'.");
    InputOutput.<String>println(_plus_3);
    ComponentType _type_1 = _self.getType();
    EList<Subcomponent> _subcomponents = _type_1.getSubcomponents();
    boolean _isEmpty = _subcomponents.isEmpty();
    if (_isEmpty) {
      EList<OutgoingPort> _outgoingPorts = _self.getOutgoingPorts();
      for (final Port p : _outgoingPorts) {
        {
          ComponentType _type_2 = _self.getType();
          final ComponentBehavior behavior = _type_2.getBehavior();
          if ((behavior instanceof GroovyComponentBehavior)) {
            final GroovyComponentBehavior gcb = ((GroovyComponentBehavior) behavior);
            String _scriptBody = gcb.getScriptBody();
            EObject result = GroovyInterpreter.interpret(_scriptBody);
            PortAspect.value(p, result);
          } else {
          }
          EObject _value = PortAspect.value(p);
          String _plus_4 = ("### Assigning value \'" + _value);
          String _plus_5 = (_plus_4 + "\' to outgoing port ");
          String _name_2 = _self.getName();
          String _plus_6 = (_plus_5 + _name_2);
          String _plus_7 = (_plus_6 + ".");
          String _name_3 = p.getName();
          String _plus_8 = (_plus_7 + _name_3);
          String _plus_9 = (_plus_8 + ".");
          InputOutput.<String>println(_plus_9);
        }
      }
    } else {
      ComponentType _type_2 = _self.getType();
      String _name_2 = _type_2.getName();
      String _plus_4 = ("=> Computing behavior for composed subcomponent \'" + _name_2);
      String _plus_5 = (_plus_4 + ".");
      String _name_3 = _self.getName();
      String _plus_6 = (_plus_5 + _name_3);
      String _plus_7 = (_plus_6 + "\'.");
      InputOutput.<String>println(_plus_7);
      ComponentType _type_3 = _self.getType();
      EList<Subcomponent> _subcomponents_1 = _type_3.getSubcomponents();
      for (final Subcomponent ci : _subcomponents_1) {
        SubcomponentAspect.compute(ci);
      }
    }
  }
}
