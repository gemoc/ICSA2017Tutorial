package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.aspects;

import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.xmontiarc.State;

@SuppressWarnings("all")
public class StateMachineAspectAutomatonComponentBehaviorAspectProperties {
  public State currentState;
  
  public String unprocessedString;
  
  public String consummedString;
  
  public String producedString;
}
