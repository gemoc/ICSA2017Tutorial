/**
 */
package fsmTrace.Steps;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fsm State Step Abstract Sub Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fsmTrace.Steps.StepsPackage#getFsm_State_Step_AbstractSubStep()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Fsm_State_Step_AbstractSubStep extends SpecificStep {
} // Fsm_State_Step_AbstractSubStep
