/**
 */
package org.gemoc.sample.legacyfsm.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater Than Number Guard</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sample.legacyfsm.fsm.FsmPackage#getGreaterThanNumberGuard()
 * @model
 * @generated
 */
public interface GreaterThanNumberGuard extends NumberGuard {
} // GreaterThanNumberGuard
