package org.gemoc.sample.legacyfsm.fsm.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.gemoc.sample.legacyfsm.fsm.Variable;

/**
 * class NonDeterminism extends Exception {
 * }
 */
@Aspect(className = Variable.class)
@SuppressWarnings("all")
public class VariableAspect {
}
