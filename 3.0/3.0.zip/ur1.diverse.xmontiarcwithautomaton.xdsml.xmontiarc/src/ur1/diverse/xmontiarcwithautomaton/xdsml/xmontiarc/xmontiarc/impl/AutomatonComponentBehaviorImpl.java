/**
 */
package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.xmontiarc.impl;

import org.eclipse.emf.ecore.EClass;

import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.xmontiarc.AutomatonComponentBehavior;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.xmontiarc.XmontiarcPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Automaton Component Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AutomatonComponentBehaviorImpl extends ComponentBehaviorImpl implements AutomatonComponentBehavior {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AutomatonComponentBehaviorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return XmontiarcPackage.Literals.AUTOMATON_COMPONENT_BEHAVIOR;
	}

} //AutomatonComponentBehaviorImpl
