package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.aspects;

@SuppressWarnings("all")
public class ComponentTypeAspectComponentTypeAspectProperties {
}
