/**
 */
package fsmTrace.Steps;

import fr.inria.diverse.trace.commons.model.trace.SmallStep;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fsm State Step Implicit Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fsmTrace.Steps.StepsPackage#getFsm_State_Step_ImplicitStep()
 * @model
 * @generated
 */
public interface Fsm_State_Step_ImplicitStep extends Fsm_State_Step_AbstractSubStep, SmallStep {
} // Fsm_State_Step_ImplicitStep
