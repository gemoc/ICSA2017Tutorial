package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.aspects;

import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public class PortAspectPortAspectProperties {
  public EObject value;
}
