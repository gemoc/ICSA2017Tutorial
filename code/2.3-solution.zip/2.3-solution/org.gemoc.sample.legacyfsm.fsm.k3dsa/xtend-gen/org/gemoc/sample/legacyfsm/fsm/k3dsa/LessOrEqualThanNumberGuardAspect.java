package org.gemoc.sample.legacyfsm.fsm.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.gemoc.sample.legacyfsm.fsm.LessOrEqualThanNumberGuard;
import org.gemoc.sample.legacyfsm.fsm.NumberVariable;
import org.gemoc.sample.legacyfsm.fsm.k3dsa.LessOrEqualThanNumberGuardAspectLessOrEqualThanNumberGuardAspectProperties;
import org.gemoc.sample.legacyfsm.fsm.k3dsa.NumberGuardAspect;
import org.gemoc.sample.legacyfsm.fsm.k3dsa.NumberVariableAspect;

@Aspect(className = LessOrEqualThanNumberGuard.class)
@SuppressWarnings("all")
public class LessOrEqualThanNumberGuardAspect extends NumberGuardAspect {
  public static boolean holds(final LessOrEqualThanNumberGuard _self) {
    final org.gemoc.sample.legacyfsm.fsm.k3dsa.LessOrEqualThanNumberGuardAspectLessOrEqualThanNumberGuardAspectProperties _self_ = org.gemoc.sample.legacyfsm.fsm.k3dsa.LessOrEqualThanNumberGuardAspectLessOrEqualThanNumberGuardAspectContext.getSelf(_self);
    Object result = null;
     if (_self instanceof org.gemoc.sample.legacyfsm.fsm.LessOrEqualThanNumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.LessOrEqualThanNumberGuardAspect._privk3_holds(_self_, (org.gemoc.sample.legacyfsm.fsm.LessOrEqualThanNumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.NumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.NumberGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.NumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.Guard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.GuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.Guard)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
    return (boolean)result;
  }
  
  protected static boolean _privk3_holds(final LessOrEqualThanNumberGuardAspectLessOrEqualThanNumberGuardAspectProperties _self_, final LessOrEqualThanNumberGuard _self) {
    final NumberVariable source = _self.getSource();
    final Long value = Long.valueOf(_self.getValue());
    Long _value = NumberVariableAspect.value(source);
    return (value.compareTo(_value) >= 0);
  }
}
