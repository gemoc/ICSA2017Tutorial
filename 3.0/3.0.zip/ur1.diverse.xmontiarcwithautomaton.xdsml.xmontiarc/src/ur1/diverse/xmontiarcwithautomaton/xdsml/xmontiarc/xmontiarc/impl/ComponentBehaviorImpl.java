/**
 */
package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.xmontiarc.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.xmontiarc.ComponentBehavior;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarc.xmontiarc.XmontiarcPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Component Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ComponentBehaviorImpl extends EObjectImpl implements ComponentBehavior {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComponentBehaviorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return XmontiarcPackage.Literals.COMPONENT_BEHAVIOR;
	}

} //ComponentBehaviorImpl
