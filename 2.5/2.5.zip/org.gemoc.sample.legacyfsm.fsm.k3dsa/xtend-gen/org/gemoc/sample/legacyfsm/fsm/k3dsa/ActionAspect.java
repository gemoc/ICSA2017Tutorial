package org.gemoc.sample.legacyfsm.fsm.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Abstract;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.gemoc.sample.legacyfsm.fsm.Action;
import org.gemoc.sample.legacyfsm.fsm.k3dsa.ActionAspectActionAspectProperties;

@Aspect(className = Action.class)
@SuppressWarnings("all")
public abstract class ActionAspect {
  @Abstract
  public static void execute(final Action _self) {
    final org.gemoc.sample.legacyfsm.fsm.k3dsa.ActionAspectActionAspectProperties _self_ = org.gemoc.sample.legacyfsm.fsm.k3dsa.ActionAspectActionAspectContext.getSelf(_self);
     if (_self instanceof org.gemoc.sample.legacyfsm.fsm.StringAction){
    					org.gemoc.sample.legacyfsm.fsm.k3dsa.StringActionAspect.execute((org.gemoc.sample.legacyfsm.fsm.StringAction)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.BooleanAction){
    					org.gemoc.sample.legacyfsm.fsm.k3dsa.BooleanActionAspect.execute((org.gemoc.sample.legacyfsm.fsm.BooleanAction)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.NumberAction){
    					org.gemoc.sample.legacyfsm.fsm.k3dsa.NumberActionAspect.execute((org.gemoc.sample.legacyfsm.fsm.NumberAction)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.Action){
    					org.gemoc.sample.legacyfsm.fsm.k3dsa.ActionAspect._privk3_execute(_self_, (org.gemoc.sample.legacyfsm.fsm.Action)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final ActionAspectActionAspectProperties _self_, final Action _self) {
    throw new java.lang.RuntimeException("Not implemented");
  }
}
