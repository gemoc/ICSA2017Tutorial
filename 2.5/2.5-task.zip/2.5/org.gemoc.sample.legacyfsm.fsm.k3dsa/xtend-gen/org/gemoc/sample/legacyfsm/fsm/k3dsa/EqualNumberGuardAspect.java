package org.gemoc.sample.legacyfsm.fsm.k3dsa;

import com.google.common.base.Objects;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.gemoc.sample.legacyfsm.fsm.EqualNumberGuard;
import org.gemoc.sample.legacyfsm.fsm.NumberVariable;
import org.gemoc.sample.legacyfsm.fsm.k3dsa.EqualNumberGuardAspectEqualNumberGuardAspectProperties;
import org.gemoc.sample.legacyfsm.fsm.k3dsa.NumberGuardAspect;
import org.gemoc.sample.legacyfsm.fsm.k3dsa.NumberVariableAspect;

@Aspect(className = EqualNumberGuard.class)
@SuppressWarnings("all")
public class EqualNumberGuardAspect extends NumberGuardAspect {
  public static boolean holds(final EqualNumberGuard _self) {
    final org.gemoc.sample.legacyfsm.fsm.k3dsa.EqualNumberGuardAspectEqualNumberGuardAspectProperties _self_ = org.gemoc.sample.legacyfsm.fsm.k3dsa.EqualNumberGuardAspectEqualNumberGuardAspectContext.getSelf(_self);
    Object result = null;
     if (_self instanceof org.gemoc.sample.legacyfsm.fsm.EqualNumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.EqualNumberGuardAspect._privk3_holds(_self_, (org.gemoc.sample.legacyfsm.fsm.EqualNumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.NumberGuard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.NumberGuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.NumberGuard)_self);
    } else  if (_self instanceof org.gemoc.sample.legacyfsm.fsm.Guard){
    					result = org.gemoc.sample.legacyfsm.fsm.k3dsa.GuardAspect.holds((org.gemoc.sample.legacyfsm.fsm.Guard)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
    return (boolean)result;
  }
  
  protected static boolean _privk3_holds(final EqualNumberGuardAspectEqualNumberGuardAspectProperties _self_, final EqualNumberGuard _self) {
    final NumberVariable source = _self.getSource();
    final Long value = Long.valueOf(_self.getValue());
    Long _value = NumberVariableAspect.value(source);
    return Objects.equal(value, _value);
  }
}
