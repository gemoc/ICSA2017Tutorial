package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.adapters.xmontiarcwithautomatonmt;

import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import java.util.Set;
import org.eclipse.emf.common.util.URI;
import ur1.diverse.xmontiarcwithautomaton.xdsml.XMontiArcWithAutomatonMT;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomatonmt.runtime.RuntimeFactory;
import ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomatonmt.xmontiarc.XmontiarcFactory;

@SuppressWarnings("all")
public class XMontiArcWithAutomatonAdapter extends ResourceAdapter implements XMontiArcWithAutomatonMT {
  public XMontiArcWithAutomatonAdapter() {
    super(ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.adapters.xmontiarcwithautomatonmt.XMontiArcWithAutomatonMTAdaptersFactory.getInstance());
  }
  
  @Override
  public XmontiarcFactory getXmontiarcFactory() {
    return new ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.adapters.xmontiarcwithautomatonmt.xmontiarc.XmontiarcFactoryAdapter();
  }
  
  @Override
  public RuntimeFactory getRuntimeFactory() {
    return new ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcwithautomaton.adapters.xmontiarcwithautomatonmt.runtime.RuntimeFactoryAdapter();
  }
  
  @Override
  public Set getFactories() {
    java.util.Set<org.eclipse.emf.ecore.EFactory> res = new java.util.HashSet<org.eclipse.emf.ecore.EFactory>();
    res.add(getXmontiarcFactory());
    res.add(getRuntimeFactory());
    return res;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
