/**
 */
package ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcmt.xmontiarc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Automaton Component Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ur1.diverse.xmontiarcwithautomaton.xdsml.xmontiarcmt.xmontiarc.XmontiarcPackage#getAutomatonComponentBehavior()
 * @model
 * @generated
 */
public interface AutomatonComponentBehavior extends ComponentBehavior {
} // AutomatonComponentBehavior
