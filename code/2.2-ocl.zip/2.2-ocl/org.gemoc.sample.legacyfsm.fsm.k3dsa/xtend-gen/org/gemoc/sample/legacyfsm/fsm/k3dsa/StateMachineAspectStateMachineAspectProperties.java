package org.gemoc.sample.legacyfsm.fsm.k3dsa;

import org.gemoc.sample.legacyfsm.fsm.State;

@SuppressWarnings("all")
public class StateMachineAspectStateMachineAspectProperties {
  public State currentState;
  
  public String unprocessedString;
  
  public String consummedString;
  
  public String producedString;
}
