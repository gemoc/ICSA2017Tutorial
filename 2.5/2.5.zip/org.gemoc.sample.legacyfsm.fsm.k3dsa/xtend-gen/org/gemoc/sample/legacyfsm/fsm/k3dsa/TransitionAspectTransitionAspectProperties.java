package org.gemoc.sample.legacyfsm.fsm.k3dsa;

@SuppressWarnings("all")
public class TransitionAspectTransitionAspectProperties {
}
