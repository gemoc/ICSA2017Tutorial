/**
 */
package org.gemoc.sample.legacyfsm.xsfsm.xsfsm.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater Or Equal Than Number Guard</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sample.legacyfsm.xsfsm.xsfsm.fsm.FsmPackage#getGreaterOrEqualThanNumberGuard()
 * @model
 * @generated
 */
public interface GreaterOrEqualThanNumberGuard extends NumberGuard {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	boolean holds();

} // GreaterOrEqualThanNumberGuard
